function p = setParameters(cond)

p.cond      = cond;
p.condnames = {'Binocular rivalry / attended','Binocular rivalry / half attended','Binocular rivalry / quarterly attended','Binocular rivalry / unattended',...
    'Monocular deprivation / attended','Monocular deprivation / half attended','Monocular deprivation / quarterly attended','Monocular deprivation / unattended'...
    'BR after (MD / attended)','BR after (MD / half attended)','BR after (MD / quarterly attended)','BR after (MD / unattended)'...
    'Simulating empirical results / attended','Simulating empirical results / fixation','Simulating empirical results / unattended','Simulating empirical results / pre'};

% experiment parameters
switch cond
    case {1,2,3,4,9,10,11,12,13,14,15,16} %Binocular rivalry
        p.input  = [0.5 0.5];   %input strength at [left eye, right eye]
        p.dt     = 5;           %time-step in forward Euler method (ms)
        p.T      = 6*60*1000;   %total duration to simulate (ms); 6 min for binocular rivalry
        p.nt     = p.T/p.dt+1;  %number of time point
        p.tlist  = 0:p.dt:p.T;  %time vector (ms)
        p.nx     = 1;           %simulate one location
        p.ntheta = 2;           %simulate two orienation
        p.thetaO = [0.31 0.31]; %threshold O at [left eye, right eye]
        p.thetaR = [0.34 0.34]; %threshold R at [left eye, right eye]

    case {5,6,7,8} %Monocular deprivation
        p.input  = [0 0.5];     %input strength at [left eye, right eye]; for monocular deprivation, only right-eye is available
        p.dt     = 5;           %time-step in forward Euler method (ms)
        p.T      = 15*60*1000;  %total duration to simulate (ms); 15 min for monocular deprivation
        p.nt     = p.T/p.dt+1;  %number of time point
        p.tlist  = 0:p.dt:p.T;  %time vector (ms)
        p.nx     = 1;           %simulate one location
        p.ntheta = 2;           %simulate two orientation
        p.thetaO = [0.6 0.6];   %threshold O at [left eye, right eye]
        p.thetaR = [0.4 0.4];   %threshold R at [left eye, right eye]

        p.ISP    = 500;         %interswap period (ms)
        p.blank  = 0;           %blank duration inserted before swap (ms); has to be smaller than ISP
end

% some properties of simulated neurons
p.nLayers        = 7; %2 monocular + 1 binocular-summation + 2 opponency + 1 attention layer
p.rectSmoothFlag = 1; %options for half-wave rectification function. 0 is non-smoothed version; 1 is the smoothed version; both work here.
%if you want to implement the model using ODE solver in MATLAB (or in Mathematica), or to run the model in AUTOp07,
%the smoothed version is preferred.

% model parameters
p.n_m    = 1;      %exponent for monocular neurons
p.n      = 2;      %exponent for all other neurons
p.sigma  = .5;     %suppression constant (for all layer, excpet attention layer, see p.sigma_a below)
p.m      = 2;      %gain (scaling factor) of monocular neurons
p.k      = 0;      %weights of contrast adapatation for monocular neurons

p.wh                = 2;           %weights of self-adaptation
p.initial_wh_m      = 2;           %weights of self-adaptation for monocular neurons
p.wa                = [0.6 0.6];   %weights of attentional modulation at [left eye, right eye]
p.initial_left_wo1  = [0.65 0.65]; %weights of mutual inhibition at left eye,orientation 1
p.initial_left_wo2  = [0.65 0.65]; %weights of mutual inhibition at left eye,orientation 2
p.initial_right_wo1 = [0.65 0.65]; %weights of mutual inhibition at right eye,orientation 1
p.initial_right_wo2 = [0.65 0.65]; %weights of mutual inhibition at right eye,orientation 2
p.tau_s             = 5;           %time constant for monocular and binocular-summation neurons
%The range 1-10 ms has been tested, and generated similar results
p.tau_o             = 20;          %time constant for opponency neurons
p.tau_a             = 150;         %time constant for attention
p.tau_h             = 2000;        %time constant for adaptation
p.tau_w             = 26500;       %time constant that controlled the learning rate of synaptic weights

% some stuff for attention layer
p.sigma_a  = .2;          %suppression constant for attention layer
p.aKernel  = [1 -1;-1 1]; %weight from binocualr summation neurons to attention neurons (subtraction in Eq.3 in the paper)

%% Set up transient/decay at stimulus onset and offset
p.alpha_t  = 3;   %parameter that influences onset transient duration (shape)
p.alphaAmp = .5;  %onset transient amplitude (relative to constant input)
p.tan_t    = 30;  %parameter that influences offset decay duration

%% condition specific settings
switch cond
    case 1 % Binocular rivalry / attended
        p.wa = [0.6 0.6];
    case 2 % Binocular rivalry / half attended
        p.wa = [0.35 0.35];
    case 3 % Binocular rivalry / quarterly attended
        p.wa = [0.2 0.2];
    case 4 % Binocular rivalry / unattended
        p.wa = [0 0];

    case 5 % Monocular deprivation / attended
        p.wa = [1.2 1.2];
    case 6 % Monocular deprivation / half attended
        p.wa = [0.8 0.8];
    case 7 % Monocular deprivation / quarterly attended
        p.wa = [0.5 0.5];
    case 8 % Monocular deprivation / unattended
        p.wa = [0 0];

    case 9  % Binocular rivalry after (monocular deprivation / attended)
        p.initial_left_wo1 = [0.3692 0.3691];
        p.initial_left_wo2 = [0.3692 0.3691];
    case 10 % Binocular rivalry after (monocular deprivation / half attended)
        p.initial_left_wo1 = [0.4914 0.4913];
        p.initial_left_wo2 = [0.4914 0.4913];
    case 11 % Binocular rivalry after (monocular deprivation / quarterly attended)
        p.initial_left_wo1 = [0.5731 0.5731];
        p.initial_left_wo2 = [0.5731 0.5731];
    case 12 % Binocular rivalry after (monocular deprivation / unattended)
        p.initial_left_wo1 = [0.6410 0.6410];
        p.initial_left_wo2 = [0.6410 0.6410];

    case 13 % Simulating empirical results / attended
        p.tau_w            = 35000;
        p.k                = 1/50000;
        p.initial_left_wo1 = [0.3978 0.3977];
        p.initial_left_wo2 = [0.3978 0.3977];
    case 14 % Simulating empirical results / fixation
        p.tau_w            = 35000;
        p.k                = 1/50000;
        p.initial_left_wo1 = [0.3982 0.3981];
        p.initial_left_wo2 = [0.3982 0.3981];
    case 15 % Simulating empirical results / unattended
        p.tau_w            = 35000;
        p.k                = 1/50000;
        p.initial_left_wo1 = [0.5069 0.5069];
        p.initial_left_wo2 = [0.5069 0.5069];
    case 16 % Simulating empirical results / pre
        p.tau_w            = 35000;
        p.k                = 1/50000;
        p.initial_left_wo1 = [0.6432 0.6432];
        p.initial_left_wo2 = [0.6432 0.6432];
end

end