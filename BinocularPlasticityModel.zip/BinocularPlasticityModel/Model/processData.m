function p = processData(p)
%EveryMin
%left,1 right,2 deprived predominance,3
%PooledOptDur
%deprived,3,5 nondeprived,4,6

left  = p.r{3}(1,:);%response of Binocular-summation neurons for orientA
right = p.r{3}(2,:);%response of Binocular-summation neurons for orientB
OutputTime = zeros(2,1);

%% computing every dominance duration
idx = 1;
for t = p.dt:p.dt:p.T
    idx = idx+1;
    if left(idx) > right(idx) && left(idx-1) <= right(idx-1)
        OutputTime = [OutputTime,[-1;p.dt*(idx-1)/1000]];
    elseif left(idx) < right(idx) && left(idx-1) >= right(idx-1)
        OutputTime = [OutputTime,[1;p.dt*(idx-1)/1000]];
    elseif left(idx) == right(idx) && left(idx-1) ~= right(idx-1)
        OutputTime = [OutputTime,[2;p.dt*(idx-1)/1000]];
    end
end

OutputDurations = [];
len = length(OutputTime);
for i = 2:len-1
    OutputDurations(1,i-1) = OutputTime(1,i);
    OutputDurations(2,i-1) = OutputTime(2,i+1) - OutputTime(2,i);
end
OutputDurations = OutputDurations';

%% computing dominance time and predominance in every min
EveryMin = [];
EveryMinDur = 60; %default 60s
i = 1;
MinDur = 0;
EveryAbsoluteDurLeft  = 0;
EveryAbsoluteDurRight = 0;
[m,~] = size(OutputDurations);

for j = 1:m
    if MinDur + OutputDurations(j,2) <= EveryMinDur
        MinDur = MinDur + OutputDurations(j,2);
        if OutputDurations(j,1) == -1
            EveryAbsoluteDurLeft  = EveryAbsoluteDurLeft + OutputDurations(j,2);
        elseif OutputDurations(j,1) == 1
            EveryAbsoluteDurRight = EveryAbsoluteDurRight + OutputDurations(j,2);
        end
        if j == m
            EveryMin(i,1) = EveryAbsoluteDurLeft;
            EveryMin(i,2) = EveryAbsoluteDurRight;
        end
    elseif MinDur+OutputDurations(j,2) > EveryMinDur
        if OutputDurations(j,1) == -1
            EveryAbsoluteDurLeft  = EveryAbsoluteDurLeft + (EveryMinDur-MinDur);
        elseif OutputDurations(j,1) == 1
            EveryAbsoluteDurRight = EveryAbsoluteDurRight + (EveryMinDur-MinDur);
        end
        EveryMin(i,1) = EveryAbsoluteDurLeft;
        EveryMin(i,2) = EveryAbsoluteDurRight;
        EveryAbsoluteDurLeft  = 0;
        EveryAbsoluteDurRight = 0;
        i=i+1;
        if OutputDurations(j,1) == -1
            EveryAbsoluteDurLeft  = EveryAbsoluteDurLeft + OutputDurations(j,2) - (EveryMinDur-MinDur);
        elseif OutputDurations(j,1) == 1
            EveryAbsoluteDurRight = EveryAbsoluteDurRight + OutputDurations(j,2) - (EveryMinDur-MinDur);
        end
        MinDur = MinDur + OutputDurations(j,2) - EveryMinDur;
    end
end

for i = 1:6
    EveryMin(i,3) = EveryMin(i,1)/(EveryMin(i,1) + EveryMin(i,2)); %predominance, set left eye as deprived eye
end

%% computing normalized mean dominance durations in quantile
len = length(OutputDurations);
PooledOptDur = OutputDurations(1,:);
for i = 2:len
    if OutputDurations(i,1) == -1 && PooledOptDur(end,1) == -1
        PooledOptDur(end,2) = PooledOptDur(end,2) + OutputDurations(i,2);
    elseif OutputDurations(i,1) == -1 && PooledOptDur(end,1) == 1
        PooledOptDur = [PooledOptDur;OutputDurations(i,:)];
    elseif OutputDurations(i,1) == 1 && PooledOptDur(end,1) == 1
        PooledOptDur(end,2) = PooledOptDur(end,2) + OutputDurations(i,2);
    elseif OutputDurations(i,1) == 1 && PooledOptDur(end,1) == -1
        PooledOptDur = [PooledOptDur;OutputDurations(i,:)];
    end
end
MDD = 2.613905109; %preBR mean dominance duration,as a baseline
%MDD = mean(PooledOptDur(:,2)); %if you want to get a baseline MDD, run this
for i = 1:length(PooledOptDur)
    if mod(i,2) == 1
        PooledOptDur((i+1)/2,3) = PooledOptDur(i,2);
    elseif mod(i,2) == 0
        PooledOptDur(i/2,4) = PooledOptDur(i,2);
    end
end
PooledOptDur(:,2:4) = PooledOptDur(:,2:4)/MDD;

if OutputDurations(1,1) == 1
    temp = PooledOptDur(:,3);
    PooledOptDur(:,3) = PooledOptDur(:,4);
    PooledOptDur(:,4) = temp;
end

t1 = sum(PooledOptDur(:,3)~=0);
t2 = sum(PooledOptDur(:,4)~=0);
k = min(floor(t1/6),floor(t2/6));
for i = 1:5
    PooledOptDur(i,5) = mean(PooledOptDur(1+(i-1)*k:k+(i-1)*k,3));
    PooledOptDur(i,6) = mean(PooledOptDur(1+(i-1)*k:k+(i-1)*k,4));
end
t1 = sum(PooledOptDur(:,3)~=0);
t2 = sum(PooledOptDur(:,4)~=0);
PooledOptDur(6,5) = mean(PooledOptDur(1+(6-1)*k:t1,3));
PooledOptDur(6,6) = mean(PooledOptDur(1+(6-1)*k:t2,4));

p.EveryMin     = EveryMin;
p.PooledOptDur = PooledOptDur;
end