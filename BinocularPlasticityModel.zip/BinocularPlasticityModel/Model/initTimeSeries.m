function p = initTimeSeries(p)

for lay = 1:p.nLayers %go through maximum possible layers. This way, if there are <5 layers, the feedback can be zero.
    p.d{lay}    = zeros(p.ntheta,p.nt); %Excitatory Drive
    p.s{lay}    = zeros(p.ntheta,p.nt); %Suppressive Drive
    p.r{lay}    = zeros(p.ntheta,p.nt); %Firing Rate
    p.f{lay}    = zeros(p.ntheta,p.nt); %Estimated asymptotic firing rate
    p.h{lay}    = zeros(p.ntheta,p.nt); %Adaptation term

    p.wo{lay}    = zeros(p.ntheta,p.nt); %Weights of mutual inhibition
    p.wo1{lay}   = zeros(p.ntheta,p.nt); %Weights of mutual inhibition for orientation 1
    p.wo2{lay}   = zeros(p.ntheta,p.nt); %Weights of mutual inhibition for orientation 2
    p.wh_m{lay}  = zeros(p.ntheta,p.nt); %Weights of self-adaptation for monocular neurons
    if ismember(lay,[1 2])
        p.o{lay} = zeros(p.ntheta,p.nt);
    end
end

%set initial value for wo
p.wo1{1}(1:2,1) = p.initial_left_wo1';
p.wo1{2}(1:2,1) = p.initial_right_wo1';
p.wo2{1}(1:2,1) = p.initial_left_wo2';
p.wo2{2}(1:2,1) = p.initial_right_wo2';

%set initial value for wh_m
p.wh_m{1}(1:2,1) = p.initial_wh_m;
p.wh_m{2}(1:2,1) = p.initial_wh_m;

% initial condition: inject random imbalance at the initial time point.
% here, it is done in terms of the imbalance between eyes. can do other random initiation.
p.r{1}(:,1) = rand*.2;
p.r{4}(:,1) = rand*.2;


