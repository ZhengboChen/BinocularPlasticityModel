%% Set condition to run

cond = 13; %Condition to simulate (16 conditions are available here)
%1.  Binocular rivalry / attended
%2.  Binocular rivalry / half attended
%3.  Binocular rivalry / quarterly attended
%4.  Binocular rivalry / unattended

%5.  Monocular deprivation / attended
%6.  Monocular deprivation / half attended
%7.  Monocular deprivation / quarterly attended
%8.  Monocular deprivation / unattended

%9.  Binocular rivalry after (monocular deprivation / attended)
%10. Binocular rivalry after (monocular deprivation / half attended)
%11. Binocular rivalry after (monocular deprivation / quarterly attended)
%12. Binocular rivalry after (monocular deprivation / unattended)

%13. Simulating empirical results / attended
%14. Simulating empirical results / fixation
%15. Simulating empirical results / unattended
%16. Simulating empirical results / pre

%%
%Setup the stimulus sequence and parameters
p      = setParameters(cond); %set parameters
p      = setStim(p);          %draw stimuli
p      = initTimeSeries(p);   %preallocate data matrices
p.i{1} = p.stimL;             %assign stimulus to the inputs of monocular layers
p.i{2} = p.stimR;             %assign stimulus to the inputs of monocular layers

%Run the model
fprintf('%s \n', p.condnames{p.cond});
p = n_model(p);

%Plot results
plotTimeSeries(p);

%Compute indices for results
switch cond
    case {13,14,15,16}
        p = processData(p);
        p = drawResults(p);
end
