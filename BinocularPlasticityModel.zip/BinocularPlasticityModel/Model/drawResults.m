function p = drawResults(p)
EveryMin     = p.EveryMin;
PooledOptDur = p.PooledOptDur;
TitleSize    = 12;
AxisSzie     = 10;
TitleName    = {'Attended','Fixation','Unattended','Pre'};

%% predominance
cpsFigure(0.9,0.8);
set(gcf,'Name',sprintf('%s',p.condnames{p.cond}));
subplot(1,2,1)
Position1 = get(gca,'Position');
set(gca,'Position',[Position1(1)-0.01 Position1(2)+0.06 Position1(3) Position1(4)-0.205])

pred     = EveryMin(:,3)*100;
baseline = 50*ones(1,6);
time     = 1:6;

h = bar(time,pred);hold on;
set(h,'FaceColor',[100,149,237]/255);
plot(time,baseline(1,:),'color','k');
ylabel('Predominance (%)')
xlabel('Time (min)')
set(gca,'FontSize',AxisSzie,'box','off')
ylim([45 85]);
xlim([0.4 6.6]);
set(gca,'ytick',45:5:85);
set(gca,'TickLength',[0.02 0])
ax = gca;
ax.XAxis.TickLength = [0 0];
title(sprintf('%s',TitleName{p.cond-12}),'FontSize',TitleSize);
box off

%% mean dominance duration
subplot(1,2,2)
Position2 = get(gca,'Position');
set(gca,'Position',[Position2(1)+0.03 Position2(2)+0.06 Position2(3) Position2(4)-0.09])

depeye    = PooledOptDur(1:6,5);
nondepeye = PooledOptDur(1:6,6);
time      = 1:6;

h3 = plot([0.4 6.6],[1 1],'--k','LineWidth',1);hold on
h2 = plot(time,nondepeye,'.-','LineWidth',1,'Color',[33,50,249]/255,...
    'MarkerEdgeColor',[33,50,249]/255,'MarkerSize',24);hold on;
h1 = plot(time,depeye,'.-','LineWidth',1,'Color',[255,61,64]/255,...
    'MarkerEdgeColor',[255,61,64]/255,'MarkerSize',24);hold on;

ylabel('Normalized mean dominance duration')
xlabel('Sequence in quantile')
set(gca,'FontSize',AxisSzie,'box','off')
ylim([0.6 2.4]);
xlim([0.7 6.3]);
set(gca,'ytick',0.6:0.2:2.4);
set(gca,'YTickLabel',num2str((get(gca,'ytick'))','%.1f'));
set(gca,'xtick',1:1:6);
set(gca,'TickLength',[0.02 0])
title(sprintf('%s',TitleName{p.cond-12}),'FontSize',TitleSize);
legend([h1,h2,h3],'Deprived eye','Non-deprived eye','Baseline')

end

function h = cpsFigure(width,height,num,name)

if exist('num','var') && ~isempty(num)
    h = figure(num);
else
    h = figure;
end
if exist('name','var')
    set(gcf,'Name',name);
end

Position = get(h,'Position');
Position(3) = width*Position(3);
Position(4) = height*Position(4);
set(h,'Position', Position,'color','w',...
    'PaperUnits','inches','PaperPosition',[0 0 width height]*4);
end